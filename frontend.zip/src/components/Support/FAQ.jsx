function FAQ() {
    return (
        <>
            <div>
                <h1>welcome to contact us</h1>
            </div>
        </>
    )
}

export default FAQ;