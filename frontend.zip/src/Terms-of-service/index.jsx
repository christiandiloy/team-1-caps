function TermsOfService() {
    return (
        <>
            <div>
                <h1>This is the terms of service.</h1>
            </div>
        </>
    )
}

export default TermsOfService;