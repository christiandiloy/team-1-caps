function ForgotPassword() {
    return (
        <>
            <div>
                <h1>Gawa ka nalang bago. jk</h1>
            </div>
        </>
    )
}

export default ForgotPassword;