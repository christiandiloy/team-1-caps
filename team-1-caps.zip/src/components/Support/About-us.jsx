function AboutUs() {
    return (
        <>
            <div>
                <h1>welcome to contact us</h1>
            </div>
        </>
    )
}

export default AboutUs;