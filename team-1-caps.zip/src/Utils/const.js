export const myExpressURL = 'http://localhost:3005';


export const serverRoutes = {
    Login:           myExpressURL + '/api/v2/login',
    Register:           myExpressURL + '/api/v2/register',
}
