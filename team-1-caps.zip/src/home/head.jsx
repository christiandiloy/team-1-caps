function Head() {
  return (
    <>
      <div className="warning">
        <p>
          <span>WARNING: </span>
          This product contains nicotine. Nicotine is an addictive chemical.
          <br />
          Only for adults. Anyone below the age of 21 is prohibited from buying
          e-cigarette.
        </p>
      </div>
    </>
  );
}

export default Head;
